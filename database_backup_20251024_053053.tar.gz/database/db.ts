// This file is for native mobile apps (iOS/Android)
// Native apps DON'T use PostgreSQL - they use SQLite
// PostgreSQL connection is only for web platform (see db.web.ts)
// This file provides stub implementations to avoid import errors

// Mock PoolClient type
interface MockPoolClient {
    query: (text: string, params?: any[]) => Promise<any>;
    release: () => void;
}

// Mock pool for type compatibility
const pool = {
    query: (text: string, params?: any[]) => {
        throw new Error('PostgreSQL not available on native apps. Use SQLite via recipes.ts instead.');
    },
    connect: (): MockPoolClient => {
        throw new Error('PostgreSQL not available on native apps. Use SQLite via recipes.ts instead.');
    },
    on: (event: string, callback: (err: Error) => void) => { },
    end: () => Promise.resolve(),
};

/**
 * Execute a query on the database
 * Note: This is a stub. Native apps use SQLite (see recipes.ts, tracking.ts)
 */
export async function query(text: string, params?: any[]) {
    throw new Error('PostgreSQL query not available on native apps. Use SQLite functions from recipes.ts or tracking.ts instead.');
}

/**
 * Get a client from the pool for transactions
 * Note: This is a stub. Native apps use SQLite
 */
export async function getClient(): Promise<MockPoolClient> {
    throw new Error('PostgreSQL not available on native apps. Use SQLite instead.');
}

/**
 * Execute a transaction
 * Note: This is a stub. Native apps use SQLite
 */
export async function transaction<T>(
    callback: (client: MockPoolClient) => Promise<T>
): Promise<T> {
    throw new Error('PostgreSQL transactions not available on native apps. Use SQLite instead.');
}

// Export the pool for advanced usage
export { pool };

// No-op graceful shutdown for native apps
if (typeof process !== 'undefined' && process.on) {
    process.on('SIGINT', async () => {
        await pool.end();
        process.exit(0);
    });

    process.on('SIGTERM', async () => {
        await pool.end();
        process.exit(0);
    });
}
